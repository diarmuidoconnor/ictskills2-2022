This archive contains the code demonstrating a custom solution for
protected routes and authentication in a React app. This code should be 
added to the Routing samples from week 5. Specifically, add this folder (sample9)
to week5Archive/routingSamples/src. Then, from the week5Archive/routingSamples/ folder,
 start the development server (npm start). Finally, edit 
 week5Archive/routingSamples/src/index.js:
------------------
import './sample7/';
-----------------