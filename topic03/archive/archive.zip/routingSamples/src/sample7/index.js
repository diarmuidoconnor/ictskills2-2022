import React from "react";
import ReactDOM from "react-dom";
import { BrowserRouter, Route, Redirect, Switch, Link } from "react-router-dom";
import Inbox from "./inbox";

const Home = () => {
  return (
    <>
      <h1>Home page</h1>
      <h3>Demo Alternative Route API</h3>
      <p>Used for passing custom props to a Route's component</p>
      <p>
        Try <Link to="/inbox/1234/statistics">User 1234</Link>
        <span> - Inbox and nested route with custom props.</span>{" "}
      </p>
      <p>
        Try <Link to="/inbox/4321/drafts">User 4321</Link>
        <span> - Inbox and standard nested route approach.</span>{" "}
      </p>
    </>
  );
};

const App = () => {
  return (
    <BrowserRouter>
      <Switch>
        <Route path="/inbox/:userId" component={Inbox} />
        <Route exact path="/" component={Home} />
        <Redirect from="*" to="/" />
      </Switch>
    </BrowserRouter>
  );
};

ReactDOM.render(<App />, document.getElementById("root"));
