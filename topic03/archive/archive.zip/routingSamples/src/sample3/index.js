import React from "react";
import ReactDOM from "react-dom";
import { BrowserRouter, Route, Redirect, Switch, Link } from "react-router-dom";
import { About } from "../sample1";
import Inbox from "./inbox";

const Home = () => {
  return (
    <>
      <h2>Home page</h2>
      <p>
        Try <Link to="/inbox/1234"> this hyperlink</Link>
        <span> or </span>
        <a href="http://localhost:3000/inbox/4321"> this one.</a>
      </p>
    </>
  );
};

const App = () => {
  return (
    <BrowserRouter>
      <Switch>
        <Route path="/about" component={About} />
        <Route path="/inbox/:userId" component={Inbox} />
        <Route exact path="/" component={Home} />
        <Redirect from="*" to="/" />
      </Switch>
    </BrowserRouter>
  );
};

ReactDOM.render(<App />, document.getElementById("root"));
