import React from "react";
import CourseModulesStatic from "../../components/exercises/01_staticComponent";

export default {
  title: "Exercises/01 - static component"  ,
  component: CourseModulesStatic,
};

export const Basic = () => {
  return <CourseModulesStatic />  ;
};
