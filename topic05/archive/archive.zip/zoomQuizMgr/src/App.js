import React, { useReducer, useEffect } from "react";
import FriendList from "./components/friendList";
import "./style.css";
import "../node_modules/bootstrap/dist/css/bootstrap.css";

const reducer = (state, action) => {
  switch (action.type) {
    case "add-to-confirmed":
      return {
        unconfirmed: state.unconfirmed.filter(
          (f) => f.email !== action.payload.friend.email
        ),
        confirmed: [...state.confirmed, action.payload.friend],
      };
    case "load-invitees":
      return { unconfirmed: [...action.payload.friends], confirmed: [] };
    case "remove-from-confirmed":
      return {
        unconfirmed: [...state.unconfirmed, action.payload.friend],
        confirmed: state.confirmed.filter(
          (f) => f.email !== action.payload.friend.email
        ),
      };
    default:
      return state;
  }
};

const PartyApp = () => {
  const [state, dispatch] = useReducer(reducer, {
    unconfirmed: [],
    confirmed: [],
  });

  useEffect(() => {
    fetch("https://randomuser.me/api/?results=10")
      .then((response) => response.json())
      .then((json) => {
        dispatch({ type: "load-invitees", payload: { friends: json.results } });
      });
  }, []);

  const confirmationReceived = (friend) => {
    dispatch({ type: "add-to-confirmed", payload: { friend: friend } });
  };

  const cancellation = (friend) => {
    dispatch({ type: "remove-from-confirmed", payload: { friend: friend } });
  };

  return (
    <div className="jumbotron">
      <div className="container-fluid">
        <div className="row">
          <div className="col-6 offset-4">
            <h1>Zoom Quiz Manager</h1>
          </div>
        </div>
        <div className="row">
          <div className="col-6">
            <h2>Awaiting confirmation</h2>
            <FriendList
              list={state.unconfirmed}
              action={confirmationReceived}
            />
          </div>
          <div className="col-6">
            <h2>Confirmed</h2>
            <FriendList list={state.confirmed} action={cancellation} />
          </div>
        </div>
      </div>
    </div>
  );
};
export default PartyApp;
