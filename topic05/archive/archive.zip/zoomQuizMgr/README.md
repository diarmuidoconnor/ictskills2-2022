This folder contains the Zoom Quiz Manager app discussed in the lecture. It was created with the create-react-app tool.

To run it:

$ npm install
$ npm start

The code demonstrates:
- useReducer hook