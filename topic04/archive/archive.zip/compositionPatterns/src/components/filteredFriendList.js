import React from "react";

const FilteredFriendList = props => {
  // console.log('Render of FilteredFriendList')
  const friends = props.list.map(item => (
    props.render(item) 
  ));
  return <ul>{friends}</ul>;
};

export default FilteredFriendList;
